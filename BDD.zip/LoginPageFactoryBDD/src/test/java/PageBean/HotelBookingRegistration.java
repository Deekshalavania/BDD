package PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HotelBookingRegistration {
WebDriver driver;

@FindBy(name="userName")
@CacheLookup
WebElement pffname;

@FindBy(name="userPwd")
@CacheLookup
WebElement pffpswrd;

@FindBy(xpath=".//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")
@CacheLookup
WebElement pffbutton;

public WebElement getPffname() {
	return pffname;
}

public void setPffname(String sname) {
	pffname.sendKeys(sname);
}

public WebElement getPffpswrd() {
	return pffpswrd;
}

public void setPffpswrd(String spswrd) {
	pffpswrd.sendKeys(spswrd);
}

public WebElement getPffbutton() {
	return pffbutton;
}

public void setPffbutton() {
	pffbutton.click();
}

public HotelBookingRegistration(WebDriver driver) {
	
	this.driver = driver;
	PageFactory.initElements(driver, this);

}


}
